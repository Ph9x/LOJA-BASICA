import{View, SafeAreaView, StatusBar, StyleSheet, Image, Text, FlatList} from "react-native";
import{list} from "./data"
import {ProductItem} from "./components/product-item"
import {Product} from "./types/Product";

function App(){
  return(
    //APP TAMANHO ios/android
    <SafeAreaView style={styles.container}>   
      <Image        //PROPRIEDADES DA IMAGEM
        source={require("./assets/hero.jpg")}
        resizeMode="cover"
        style={styles.hero}
      />

      <View style={styles.area}>     
        <Text style={styles.h1}>Produtos</Text>
        <FlatList
          data={list}   //DADOS
          renderItem={({item}:{item: Product}) => (     //RENDERIZAR(MOSTRAR)
            <ProductItem product={item}/> //CONSIGO MANDAR CADA UMA DAS INFOS SEM DECLARAR UMA POR UMA
          )}   
          keyExtractor={item => item.id.toString()}   //DADO PRINCIPAL produto 
        />
      </View>
    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  container:{                             //ESTILIZAÇÃO ios/android
    marginTop: StatusBar.currentHeight || 0
  },
  hero:{
    width:"100%",
    height:120
  },
  area:{
    padding:10,
  },
  h1:{
    fontSize: 24,
    marginBottom: 10
  }
})
export default App;