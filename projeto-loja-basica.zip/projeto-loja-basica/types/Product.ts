export type Product = {     //TIPO DE DADO DE UM PRODUTO ESPECÍFICO
  id: number,
  image: string;
  name: string;
  price:number
}